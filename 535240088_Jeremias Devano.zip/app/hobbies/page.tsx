"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import "bootstrap/dist/css/bootstrap.min.css";

export default function HobbiesPage() {
  const [hobbies, setHobbies] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");

  // ambil & inisialisasi localStorage
  useEffect(() => {
    const saved = localStorage.getItem("hobbies");

    if (saved) {
      setHobbies(JSON.parse(saved));
    } else {
      // Daftar hobi otomatis
      const defaultList: string[] = [
        "Main Bola",
        "Main Games",
        "Nonton Film",
        "Traveling",
        "Memasak",
        "Olahraga",
        "Baca Buku",
        "Fotografi",
        "Menggambar",
        "Mendaki Gunung"
      ];

      setHobbies(defaultList);
      localStorage.setItem("hobbies", JSON.stringify(defaultList));
    }
  }, []);

  // simpan otomatis ke localStorage setiap ada perubahan
  useEffect(() => {
    localStorage.setItem("hobbies", JSON.stringify(hobbies));
  }, [hobbies]);

  const addItem = () => {
    if (inputValue.trim() === "") return;
    setHobbies([...hobbies, inputValue]);
    setInputValue("");
  };

  const deleteItem = (index: number) => {
    const newList = hobbies.filter((_, i) => i !== index);
    setHobbies(newList);
  };

  return (
    <div className="container py-5">
      <div className="card p-4 shadow-sm">
        <h2 className="mb-4 fw-bold text-center">Daftar Hobi</h2>

        {/* Input */}
        <div className="input-group mb-4">
          <input
            type="text"
            className="form-control form-control-lg"
            placeholder="Tambahkan hobi..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button onClick={addItem} className="btn btn-success btn-lg px-4">
            Add
          </button>
        </div>

        {/* Jika data kosong */}
        {hobbies.length === 0 && (
          <p className="text-muted text-center">
            Belum ada hobi. Tambahkan dulu ya 😊
          </p>
        )}

        {/* Card list */}
        <ul className="list-group">
          {hobbies.map((item, index) => (
            <li key={index} className="list-group-item border-0 p-0 mb-3">
              <div className="card p-3 d-flex flex-row justify-content-between align-items-center shadow-sm">
                <Link
                  href={`/hobbies/${index}`}
                  className="fw-semibold text-decoration-none"
                >
                  {item}
                </Link>

                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => deleteItem(index)}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>

        <div className="text-center mt-4">
          <Link href="/" className="btn btn-secondary px-4 py-2">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
