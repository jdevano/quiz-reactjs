(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2c8f6e0c._.js",
  "static/chunks/4b556_next_dist_compiled_react-dom_7fe416f1._.js",
  "static/chunks/4b556_next_dist_compiled_react-server-dom-turbopack_018c4149._.js",
  "static/chunks/4b556_next_dist_compiled_next-devtools_index_e5f7e407.js",
  "static/chunks/4b556_next_dist_compiled_29881c58._.js",
  "static/chunks/4b556_next_dist_client_62172197._.js",
  "static/chunks/4b556_next_dist_9cc1f338._.js",
  "static/chunks/4b556_@swc_helpers_cjs_4f1529ef._.js"
],
    source: "entry"
});
