module.exports = [
"[project]/quiz-reactjs/.next-internal/server/app/hobbies/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz-reactjs__next-internal_server_app_hobbies_%5Bid%5D_page_actions_3227cbf1.js.map