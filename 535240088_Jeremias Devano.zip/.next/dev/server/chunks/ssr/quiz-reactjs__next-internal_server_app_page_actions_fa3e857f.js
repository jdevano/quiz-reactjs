module.exports = [
"[project]/quiz-reactjs/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz-reactjs__next-internal_server_app_page_actions_fa3e857f.js.map