module.exports = [
"[project]/quiz-reactjs/.next-internal/server/app/hobbies/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz-reactjs__next-internal_server_app_hobbies_page_actions_b7a4d4d2.js.map