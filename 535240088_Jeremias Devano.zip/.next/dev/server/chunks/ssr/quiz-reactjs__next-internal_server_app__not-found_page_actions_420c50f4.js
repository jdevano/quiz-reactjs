module.exports = [
"[project]/quiz-reactjs/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz-reactjs__next-internal_server_app__not-found_page_actions_420c50f4.js.map